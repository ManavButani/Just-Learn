x = ('apple', 'banana', 'cherry')
print(x)