class ABCD:
    def ok(self):
        print("I am Manav Butani")