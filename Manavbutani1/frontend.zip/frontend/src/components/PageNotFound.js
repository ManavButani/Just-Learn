import React from 'react'

const PageNotFound = () => {

  return (
    <div className='loading'>
        <h1>404 Page Not Found</h1>
    </div>
  )
}

export default PageNotFound