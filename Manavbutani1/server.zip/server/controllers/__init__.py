"""Combine all controllers
"""
__all__ = ["auth_controller", "role_controller", "user_controller", "admin_controller", "vm_controller", "jira_controller"]
